using Microsoft.Extensions.Hosting;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace io_projekt.Models
{
    public class Model
    {
        public List<User> Users = new List<User>();
        public List<Thread> Threads = new List<Thread>();
        public void connectToDataBase()
        {
            try
            {

                String connectionString = "Data Source=DESKTOP-PB1RK30\\SQLEXPRESS;Integrated Security=True;Connect Timeout=30;Encrypt=False;";

                using (SqlConnection connection  = new SqlConnection(connectionString))
                {
                    Console.WriteLine("tabela: ");
                    connection.Open();
                    String query = "select * from dbo.Watki";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {

                            while (reader.Read())
                            {
                                Thread thread = new Thread();
                                thread.setID(reader.GetInt32(0));
                                thread.setTheme(reader.GetString(1));
                                thread.setCreationDate(reader.GetDateTime(2));
                                thread.setUserID(reader.GetInt32(3));

                                Threads.Add(thread);
                            }
                        }
                    }

                    query = "select * from dbo.Wpisy";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {

                            while (reader.Read())
                            {
                                Post post = new Post();
                                post.setID(reader.GetInt32(0));
                                post.setContent(reader.GetString(1));
                                post.setCreationDate(reader.GetDateTime(2));
                                post.setThreadID(reader.GetInt32(3));
                                post.setUserID(reader.GetInt32(4));
                               
                                foreach (var thread in Threads) {
                                    if (thread.getID() == post.getThreadID()) { 
                                        List<Post> posts = thread.getPosts();
                                        posts.Add(post);
                                    }
                                }
                            }
                        }
                    }


                    query = "select * from dbo.uzytkownicy";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        using(SqlDataReader reader = command.ExecuteReader()) {
                           
                            while (reader.Read())
                            {
                                User user  = new User();
                                user.setID(reader.GetInt32(0));
                                user.setName(reader.GetString(1));
                                
                                Console.WriteLine(user.getName(), user.getID());
                                Users.Add(user);
                            }
                        }
                    }




                    
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }

    public class User {
        private int id;
        private string name;
        public int getID() { return id; }
       
        public string getName() { return name; }
        public void setName(string name) { this.name = name;}

        public void setID(int id) {  this.id = id; }

        
    }

    public class Thread { 
        private int id;
        
        private string theme;

        private DateTime creationDate;
        
        private int userID;

        private List<Post> posts = new List<Post>();

        public int getID() { return id; }
        public string getTheme() { return theme; }
        public DateTime getCreationDate() { return creationDate; }

        public int getUserID() { return userID; }
        public void setID(int ID) {  this.id = ID; }
        public void setTheme(String theme) { this.theme = theme; }
        public void setUserID(int userID) { this.userID = userID; }
        
        public void setCreationDate(DateTime creationDate) {  this.creationDate = creationDate; }

        public List<Post> getPosts() { return posts; }
        public void setPosts(List<Post> posts) {  this.posts = posts; }


    }

    public class Post {
        private int id;
        private string content;
        private DateTime creationDate;
        private int threadID;
        private int userID;

        public int getID() { return id; }
        public string getContent() { return content; }
        public int getUserID() { return userID;}
        public void setID(int id) { this.id = id; }
        public int getThreadID() { return threadID; }

        public DateTime getCreationDate() {return creationDate;}

        public void setCreationDate(DateTime creationDate) { this.creationDate = creationDate; }
        public void setContent(String content) { this.content = content;}
        public void setThreadID(int threadID) {  this.threadID = threadID; }
        public void setUserID(int userID) { this.userID = userID; }
    }


}